<?php

/**
 * return
 *
 * @file return.php
 * @author Henrik Söderlind <henrik.soderlind@live.se>
 * @created 2016-mar-18
 */

class SantandereasycontractReturnModuleFrontController 
extends ModuleFrontController
{
    /**
     * @see: FrontController:postProcess()
     */
    public function postProcess()
    {
        $cart = $this->context->cart;
        if ($cart->id_customer == 0 ||
            $cart->id_address_delivery == 0 ||
            $cart->id_address_invoice == 0 ||
            !$this->module->active)
            Tools::redirect('index.php?controller=order&step=1');
        
        $authorized = false;
        foreach (Module::getPaymentModules() as $module) {
            if ($module['name'] == 'santandereasycontract') {
                $authorized = true;
                break;
            }
        }
        
        if (!$authorized)
            die(); /* @todo: print a nice message here */
        
        $customer = new Customer($cart->id_customer);
		if (!Validate::isLoadedObject($customer))
			Tools::redirect('index.php?controller=order&step=1');
        
        $total = (float)$cart->getOrderTotal(true, Cart::BOTH);
        $currency = $this->context->currency;
        
        // Get result from web service
        $token = str_replace(array('/', '+'), array('%2f', '%2b'), $_GET['token']);
        $result = Santander::$api->getResult($token, $cart->id);
        
        /**
         * If an error, i.e no connection with the webservice, we redirect the
         * customer back to checkout.
         */
        if (!$result) {
            $this->module->displayError(Santander::$api->_('An error occured while communicating with Santander Consumer Bank. Try again or choose another payment method.'));
            Tools::redirect('index.php?controller=order&step=1');
        }
        /**
         * If we did not got any good result we redirect the customer back to the
         * checkout.
         */
        elseif (!$result->isOk) {
            $this->module->displayError($this->_result->humanFailureMessage);
        }
        
        $message = 
            Santander::$api->_(
                'Santander Consumer Bank order number: {orderNumber}', 
                array(
                    'orderNumber' => $cart->id
                )
            )
            .'. '.
            Santander::$api->_(
                'Authorization receipt to be used when capturing the amount from your payment service provider: {authorizationCode}', 
                array(
                    'authorizationCode' => $result->authorizationCode
                )
            );
        
        $this->module->validateOrder(
            $cart->id, 
            Configuration::get('SANEAS_ORDER_STATUS'), 
            $total, 
            Santander::$api->_('Monthly instalment'),
            $message, 
            array(), 
            (int)$currency->id, 
            false,
            $customer->secure_key
        );
        Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);
    }
}
