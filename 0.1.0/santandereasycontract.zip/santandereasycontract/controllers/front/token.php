<?php

/**
 * token
 *
 * @file token.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @created 2016-mar-18
 */

class SantandereasycontractTokenModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        if (!isset($_SESSION)) {
            session_start();
        }
        
        parent::initContent();
        
        $cart = $this->context->cart;
        $orderNumber = $cart->id;
        $purchaseAmount = $cart->getOrderTotal(true, Cart::BOTH);
        
        // Get token from web service
        $token = Santander::$api->getToken($orderNumber, $purchaseAmount);
        if ($token != null && $token->isOk) {
            $_SESSION['santander.token'] = $token->token;
            print Tools::jsonEncode(array(
                'isOk'          =>  $token->isOk,
                'errorMessage'  =>  $token->errorMessage,
                'redirectUrl'   =>  Santander::$api->config->getRedirectUrl($token->token),
            ));
        }
        else {
            Tools::jsonEncode(array(
                'isOk'          =>  $token->isOk,
                'errorMessage'  =>  $token->errorMessage,
            ));
        }
    }
}
