<?php

/**
 * @file santandereasycontract.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @created 2016-mar-15
 */

if (!defined('_PS_VERSION_'))
    exit;

defined('SANTANDER_EASYCONTRACT_ROOT_DIR') or define('SANTANDER_EASYCONTRACT_ROOT_DIR', __DIR__);

require_once 'lib/src/autoloader.php';
require_once 'classes/SantanderApiConnector.php';
require_once 'classes/SantanderEasycontract.php';

if (!Santander::isRunning())
    Santander::run(new SantanderApiConnector());