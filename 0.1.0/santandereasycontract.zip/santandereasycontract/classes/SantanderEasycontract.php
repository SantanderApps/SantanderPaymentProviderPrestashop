<?php
/**
 * SantanderEasycontract
 *
 * @file SantanderEasycontract.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @created 2016-mar-17
 */

class SantanderEasycontract extends PaymentModule
{
    public $returnUrl;
    
    const STATUS_TEST = 'sandbox (test environment)';
    const STATUS_LIVE = 'live';
    
    public function __construct()
    {
        static $smartyPluginsRegistered = false;
        
        $this->name = 'santandereasycontract';
        $this->tab = 'payments_gateways';
        $this->version = '0.1.0';
        $this->author = 'Consid AB';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = array('min' => '1.5', 'max' => '1.6');
        $this->bootstrap = true;
        
        $this->currencies = true;
        $this->currencies_mode = 'checkbox';
        
        parent::__construct();
        
        $this->displayName = Santander::$api->_('Santander Consumer Bank').' - '.Santander::$api->_('Monthly instalment');
        $this->description = Santander::$api->_('Santander Consumer Bank - Monthly instalment payment gateway supports customer credit applications with Santander Consumer Bank Services.');
        
        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
        
        $this->returnUrl = $this->context->link->getModuleLink('santandereasycontract', 'return');
        
        if (!$smartyPluginsRegistered) {
            $this->context->smarty->registerPlugin('function', 'saneas_l', array($this, 'smartySaneasL'));
            $smartyPluginsRegistered = true;
        }
    }
    
    public function install()
    {
        if (!parent::install() ||
            !$this->registerHook('payment') ||
            !$this->registerHook('paymentReturn') ||
            !$this->registerHook('header'))
            return false;
        
        Configuration::updateValue('SANEAS_INSTALLATION_DATE', date('Y-m-d H:i:s'));
        Configuration::updateValue('SANEAS_STORE_ID', 'EasyStubTesters');
        Configuration::updateValue('SANEAS_USERNAME', 'testbutik1');
        Configuration::updateValue('SANEAS_PASSWORD', 'testbutik1');
        Configuration::updateValue('SANEAS_MERCHANT_ID', '');
        Configuration::updateValue('SANEAS_TEST_ENV', 1);
        Configuration::updateValue('SANEAS_ACCESS_LOG_EXTERNAL', 0);
        Configuration::updateValue('SANEAS_ORDER_STATUS', 0);
        
        return true;
    }
    
    public function uninstall()
    {
        if (!parent::uninstall())
            return false;
        
        Configuration::deleteByName('SANEAS_INSTALLATION_DATE');
        Configuration::deleteByName('SANEAS_STORE_ID');
        Configuration::deleteByName('SANEAS_USERNAME');
        Configuration::deleteByName('SANEAS_PASSWORD');
        Configuration::deleteByName('SANEAS_MERCHANT_ID');
        Configuration::deleteByName('SANEAS_TEST_ENV');
        Configuration::deleteByName('SANEAS_ACCESS_LOG_EXTERNAL');
        Configuration::deleteByName('SANEAS_ORDER_STATUS');
        
        return true;
    }
    
    public function getContent()
    {
        $output = null;
        $hasErrors = false;
        
        if (Tools::isSubmit('submit'.$this->name)) {
            $saneas_store_id = Tools::getValue('saneas_store_id');
            $saneas_username = Tools::getValue('saneas_username');
            $saneas_password = Tools::getValue('saneas_password');
            $saneas_merchant_id = Tools::getValue('saneas_merchant_id');
            $saneas_test_env = Tools::getValue('saneas_env_test');
            $saneas_access_log_external = Tools::getValue('saneas_access_log_external_on');
            $saneas_order_status = Tools::getValue('saneas_order_status');
            
            if (empty($saneas_store_id)) {
                $hasErrors = true;
                $output .= $this->displayError($this->l('"Store ID" must not be empty.'));
            }
            
            if (empty($saneas_username)) {
                $hasErrors = true;
                $output .= $this->displayError($this->l('"Username" must not be empty.'));
            }
            
            if (empty($saneas_password)) {
                $hasErrors = true;
                $output .= $this->displayError($this->l('"Password" must not be empty'));
            }
            
            if (!$saneas_test_env && empty($saneas_merchant_id)) {
                $hasErrors = true;
                $output .= $this->displayError($this->l('"Merchant ID" must not be empty when in production.'));
            }
            
            if ((int)$saneas_test_env !== 1 && (int)$saneas_test_env !== 0) {
                $hasErrors = true;
                $output .= $this->displayError($this->l('"Enable sandbox/test environment" must be trur or false.'));
            }
            
            if (!$hasErrors) {
                Configuration::updateValue('SANEAS_STORE_ID', $saneas_store_id);
                Configuration::updateValue('SANEAS_USERNAME', $saneas_username);
                Configuration::updateValue('SANEAS_PASSWORD', $saneas_password);
                Configuration::updateValue('SANEAS_MERCHANT_ID', $saneas_merchant_id);
                Configuration::updateValue('SANEAS_TEST_ENV', (int)$saneas_test_env);
                Configuration::updateValue('SANEAS_ACCESS_LOG_EXTERNAL', (int)$saneas_access_log_external);
                Configuration::updateValue('SANEAS_ORDER_STATUS', (int)$saneas_order_status);
            }
        }
        
        if (Tools::getValue('connection_test')) {
            $wsdlConnection = Santander::$api->getTransferInformation();
            $sfConnection = Santander::$api->getTransferInformation('sf');
            
            if ($wsdlConnection['success']) {
                $this->adminDisplayInformation(Santander::$api->_('Success! Connected to {host}', array('{host}' => parse_url($wsdlConnection['info']['url'], PHP_URL_HOST))));
            } else {
                $this->adminDisplayWarning(Santander::$api->_('<p>Error! Failed to connect to {host}.<br>It may be due to some of the following reasons:</p><ul><li>The server is not available at the moment.</li><li>Your server do not have an outbound Internet connection.</li></ul>', array('{host}' => parse_url($wsdlConnection['info']['url'], PHP_URL_HOST))));
            }
            
            if ($sfConnection['success']) {
                $this->adminDisplayInformation(Santander::$api->_('Success! Connected to {host}', array('{host}' => parse_url($sfConnection['info']['url'], PHP_URL_HOST))));
            } else {
                $this->adminDisplayWarning(Santander::$api->_('<p>Error! Failed to connect to {host}.<br>It may be due to some of the following reasons:</p><ul><li>The server is not available at the moment.</li><li>Your server do not have an outbound Internet connection.</li></ul>', array('{host}' => parse_url($sfConnection['info']['url'], PHP_URL_HOST))));
            }
        }
        
        if (Tools::getValue('verify_details')) {
            if (Santander::$api->testConnection(uniqid())) {
                $this->adminDisplayInformation(Santander::$api->_('Success! The test connection with the web service works great. Your account details is correct.'));
            } else {
                $this->adminDisplayWarning(Santander::$api->_('Error! The test connection with the web service failed. It seems like your account details are incorrect. Make sure that they are correct, if it still doesn\'t work please {contactUs}.', array('contactUs' => '<a href="' . Santander::$api->config->getClientSiteUrl() . '" target="_blank"><u>contact us</u></a>')));
            }
        }
        
        return $output.$this->displayForm();
    }
    
    public function displayForm()
    {
        $defaultLang = Configuration::get('PS_LANG_DEFAULT');
        $orderStates = array();
        
        foreach (OrderState::getOrderStates($defaultLang) as $orderState) {
            $orderStates[] = array(
                'id'    =>  $orderState['id_order_state'],
                'name'  =>  $orderState['name']
            );
        }
        
        $fields_form = array();
        $fields_form[0]['form'] = array(
            'legend' => array(
                'title' => Santander::$api->_('Information'),
            ),
            'input' => array(
                array(
                    'name'          =>  'saneas_version',
                    'type'          =>  'html',
                    'label'         =>  Santander::$api->_('Version'),
                    'html_content'  =>  '<div class="form-control-static">'.Santander::$api->config->getModuleVersion().'</div>',
                ),
                array(
                    'name'          =>  'saneas_return_url',
                    'type'          =>  'html',
                    'label'         =>  Santander::$api->_('Return URL'),
                    'html_content'  =>  '<div class="form-control-static">'.Santander::$api->config->getReturnUrl().'</div>',
                ),
            ),
        );
        
        $fields_form[1]['form'] = array(
            'legend' => array(
                'title' => Santander::$api->_('Settings'),
            ),
            'input' => array(
                array(
                    'name'      =>  'saneas_order_status',
                    'type'      =>  'select',
                    'label'     =>  Santander::$api->_('New order status'),
                    'desc'      =>  Santander::$api->_('Status of order when order created, but before it has been processed by Santander Consumer Bank'),
                    'required'  =>  true,
                    'options'   =>  array(
                        'query' =>  $orderStates,
                        'id'    =>  'id',
                        'name'  =>  'name'
                    )
                ),
                array(
                    'name'      =>  'saneas_store_id',
                    'type'      =>  'text',
                    'label'     =>  Santander::$api->_('Store ID'),
                    'desc'      =>  Santander::$api->_('Type the store ID given to you by Santander Consumer Bank.'),
                    'required'  =>  true,
                ),
                array(
                    'name'      =>  'saneas_username',
                    'type'      =>  'text',
                    'label'     =>  Santander::$api->_('Username'),
                    'desc'      =>  Santander::$api->_('Type the username given to you by Santander Consumer Bank.'),
                    'required'  =>  true,
                ),
                array(
                    'name'      =>  'saneas_password',
                    'type'      =>  'text',
                    'label'     =>  Santander::$api->_('Password'),
                    'desc'      =>  Santander::$api->_('Type the password given to you by Santander Consumer Bank.'),
                    'required'  =>  true,
                ),
                array(
                    'name'      =>  'saneas_marchent_id',
                    'type'      =>  'text',
                    'label'     =>  Santander::$api->_('Merchant ID'),
                    'desc'      =>  Santander::$api->_('Type the merchant ID given to you by your payment service provider.'),
                ),
                array(
                    'name'      =>  'saneas_env',
                    'type'      =>  'checkbox',
                    'label'     =>  Santander::$api->_('Set Module Environment'),
                    'values'    => array(
                        'query' => array(
                            array(
                                'id'    =>  'test',
                                'name'  =>  Santander::$api->_('Enable sandbox/test environment'),
                                'val'   =>  '1'
                            ),
                        ),
                        'id'    =>  'id',
                        'name'  =>  'name'
                    ),
                ),
                array(
                    'name'      =>  'saneas_access_log_external',
                    'type'      =>  'checkbox',
                    'label'     =>  Santander::$api->_('Support Logs'),
                    'values'    => array(
                        'query' => array(
                            array(
                                'id'    =>  'on',
                                'name'  =>  Santander::$api->_('For a better support experience Santander´s plugin logs all connections to and from Santander´s web services. You have the option to opt-out of these logs being automatically collected by Santander and can therefore choose to manually send in a log file when contacting Santander support services. Log files are located: {logdir}.', array('{logdir}' => Santander::$api->config->getLogDir())),
                                'val'   =>  '1'
                            ),
                        ),
                        'id'    =>  'id',
                        'name'  =>  'name'
                    ),
                ),
            ),
            'submit' => array(
                'title' => Santander::$api->_('Save'),
                'class' => 'btn btn-default pull-right',
            ),
        );
        
        $fields_form[2]['form'] = array(
            'legend' => array(
                'title' => Santander::$api->_('Test connection'),
            ),
            'input' => array(
                array(
                    'name'          =>  'saneas_test_connection',
                    'type'          =>  'html',
                    'label'         =>  '',
                    'html_content'  =>  '<a href="'.AdminController::$currentIndex.'&configure='.$this->name.'&connection_test=1&token='.Tools::getAdminTokenLite('AdminModules').'">'.Santander::$api->_('Test connection with the web service').'</a>'
                ),
                array(
                    'name'          =>  'saneas_verift_details',
                    'type'          =>  'html',
                    'label'         =>  '',
                    'html_content'  =>  '<a href="'.AdminController::$currentIndex.'&configure='.$this->name.'&verify_details=1&token='.Tools::getAdminTokenLite('AdminModules').'">'.Santander::$api->_('Verify user details').'</a> '.Santander::$api->_('<strong>Note:</strong> Only available when "Module Environment" is set to "{statusLive}".', array('{statusLive}' => 'false')),
                ),
            ),
        );
        
        $helper = new HelperForm();
        $helper->module = $this;
        $helper->name_controller = $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
        $helper->default_form_language = $defaultLang;
        $helper->allow_employee_form_lang = $defaultLang;
        $helper->title = $this->displayName;
        $helper->submit_action = 'submit'.$this->name;
        
        $helper->fields_value['saneas_store_id'] = Configuration::get('SANEAS_STORE_ID');
        $helper->fields_value['saneas_enabled_enabled'] = (int)Configuration::get('SANEAS_ENABLED');
        $helper->fields_value['saneas_username'] = Configuration::get('SANEAS_USERNAME');
        $helper->fields_value['saneas_password'] = Configuration::get('SANEAS_PASSWORD');
        $helper->fields_value['saneas_marchent_id'] = Configuration::get('SANEAS_MARCHENT_ID');
        $helper->fields_value['saneas_env_test'] = (int)Configuration::get('SANEAS_TEST_ENV');
        $helper->fields_value['saneas_access_log_external_on'] = (int)Configuration::get('SANEAS_ACCESS_LOG_EXTERNAL');
        $helper->fields_value['saneas_order_status'] = (int)Configuration::get('SANEAS_ORDER_STATUS');
        
        return $helper->generateForm($fields_form);
    }
    
    /***************************************************************************
     * SMARTY PLUGINS 
     **************************************************************************/
    
    public function smartySaneasL($params)
    {
        return Santander::$api->_($params['s']);
    }
    
    /***************************************************************************
     * HOOKS 
     **************************************************************************/
    
    public function hookHeader()
    {
        $this->context->controller->addCss($this->_path.'css/styles.css', 'all');
        $this->context->controller->addJs($this->_path.'js/main.js');
    }
    
    public function hookPayment($params)
    {
        if (!$this->active)
            return false;
        if (!$this->hasAllowedCurrencies($params))
            return false;
        
        $this->smarty->assign(array(
            'saneas_path'       =>  $this->_path,
            'saneas_path_se'    =>  $this->_path,
            'saneas_path_ssl'   =>  Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->name.'/',
            'saneas_ajax_url'   =>  $this->context->link->getModuleLink('santandereasycontract', 'token'),
        ));
        
        return $this->display(SANTANDER_EASYCONTRACT_ROOT_DIR, 'payment.tpl');
    }
    
    public function hookPaymentReturn($params)
    {
        if (!$this->active)
            return false;
        
        return $this->display(SANTANDER_EASYCONTRACT_ROOT_DIR, 'confirmation.tpl');
    }
    
    /***************************************************************************
     * PRIVATE METHODS 
     **************************************************************************/
    
    private function hasAllowedCurrencies($params)
    {
        $allowedCurrencies = $this->getCurrency((int)$params['cart']->id_currency);
        foreach ($allowedCurrencies as $allowedCurrency) {
            if ($allowedCurrency['id_currency'] == $params['cart']->id_currency);
            return true;
        }
        
        return false;
    }
}
