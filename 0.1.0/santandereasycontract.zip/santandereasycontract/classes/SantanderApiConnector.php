<?php
/**
 * SantanderApiConnector
 *
 * @file SantanderApiConnector.php
 * @author Consid AB <henrik.soderlind@consid.se>
 * @created 2016-mar-17
 */

use Santander\base\Config;

class SantanderApiConnector implements Santander\base\APIConnectorInterface
{
    public function getData($configKey)
    {
        switch ($configKey) {
            case Config::CONFIG_KEY_TEST_MODE:
                return $this->getMode() == SantanderEasycontract::STATUS_TEST;
            
            case Config::CONFIG_KEY_SANDBOX_MODE:
                return $this->getMode() == SantanderEasycontract::STATUS_TEST;
            
            case Config::CONFIG_KEY_STORE_ID:
                return $this->getStoreId();
            
            case Config::CONFIG_KEY_USERNAME:
                return $this->getUsername();
            
            case Config::CONFIG_KEY_PASSWORD:
                return $this->getPassword();
            
            case Config::CONFIG_KEY_CERTIFICATE:
                return $this->getCertificate();
            
            case Config::CONFIG_KEY_MERCHANT_ID:
                return $this->getMerchantId();
            
            case Config::CONFIG_KEY_LANGUAGE:
                return $this->getLanguage();
            
            case Config::CONFIG_KEY_SITE_EMAIL_ADDRESS:
                return $this->getSiteMail();
            
            case Config::CONFIG_KEY_SITE_NAME:
                return $this->getSiteName();
            
            case Config::CONFIG_KEY_PLATFORM_NAME:
                return $this->getPlatformName();
            
            case Config::CONFIG_KEY_PLATFORM_VERSION:
                return $this->getPlatformVersion();
            
            case Config::CONFIG_KEY_MODULE_VERSION:
                return $this->getModuleVersion();
            
            case Config::CONFIG_KEY_MODULE_INSTALLATION_DATE:
                return $this->getModuleInstallationDate();
            
            case Config::CONFIG_KEY_ENABLE_EXTENDED_LOGGING:
                return $this->enableExtendedLogging();
            
            case Config::CONFIG_KEY_RETURN_URL:
                return $this->getReturnUrl();
            
            case Config::CONFIG_KEY_ACCESS_LOG_EXTERNAL:
                return $this->getAccessLogExternal();
            
            case Config::CONFIG_KEY_LOG_DIR:
                return $this->getLogDir();
        }
    }

    private function getMode()
    {
        $testEnv = Configuration::get('SANEAS_TEST_ENV');
        $statusTest = SantanderEasycontract::STATUS_TEST;
        $statusLive = SantanderEasycontract::STATUS_LIVE;
        return $testEnv == 1 ? $statusTest : $statusLive;
    }

    private function getStoreId()
    {
        return Configuration::get('SANEAS_STORE_ID');
    }

    private function getUsername()
    {
        return Configuration::get('SANEAS_USERNAME');
    }

    private function getPassword()
    {
        return Configuration::get('SANEAS_PASSWORD');
    }

    private function getCertificate()
    {
        return false;
    }

    private function getMerchantId()
    {
        return Configuration::get('SANEAS_MERCHANT_ID');
    }

    private function getLanguage()
    {
        return Language::getIsoById((int)Context::getContext()->cookie->id_lang);
    }

    private function getSiteMail()
    {
        return Configuration::get('PG_SHOP_EMAIL');
    }

    private function getSiteName()
    {
        return Configuration::get('PS_SHOP_NAME');
    }

    private function getPlatformName()
    {
        return 'Prestashop';
    }

    private function getPlatformVersion()
    {
        return _PS_VERSION_;
    }

    private function getModuleVersion()
    {
        $module = new SantanderEasycontract();
        return $module->version;
    }

    private function getModuleInstallationDate()
    {
        return Configuration::get('SANEAS_INSTALLATION_DATE');
    }

    private function enableExtendedLogging()
    {
        return true;
    }

    private function getReturnUrl()
    {
        $module = new SantanderEasycontract();
        return $module->returnUrl;
    }

    private function getAccessLogExternal()
    {
        return Configuration::get('SANEAS_ACCESS_LOG_EXTERNAL');
    }
    
    private function getLogDir()
    {
        return _PS_ROOT_DIR_.'/log/santander';
    }
}
