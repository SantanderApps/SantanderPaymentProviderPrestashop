(function($) {
    $(function() {
        $('body').on('click', '[data-action="santander.getToken"]', function(e) {
            e.preventDefault();
            
            var $this = $(this);
            $.getJSON($this.data('ajaxurl'), {ajax: true})
                .done(function(data) {
                    if (data.isOk) {
                        window.location = data.redirectUrl;
                    } else {
                        alert(data.errorMessage);
                    }
                });
        });
    });
}(jQuery));