<?php

/**
 * Market
 *
 * @file Market.php
 * @author Consid S5 AB <henrik.soderlind@consid.se>
 * @version 1.0.0
 * @created 2015-aug-04
 */

namespace Santander\i18n;

class Market {
    public $country;
    
    public $currency;
}
